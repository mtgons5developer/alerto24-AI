# ARLT - Coin https://coinmanufactory.com ETH Network

Status: Not started

![Untitled](ARLT%20-%20Coin%20https%20coinmanufactory%20com%20ETH%20Network%20ff57205948d84a30ab905d4cc3ec7799/Untitled.png)

Here is an example of how to implement an Ethereum wallet in Flutter using the **`web3dart`** plugin. This code demonstrates how to generate a new Ethereum account, display the account balance, and send a transaction to another Ethereum address.

First, add the following dependencies to your **`pubspec.yaml`** file:

```yaml
dependencies:
  flutter:
    sdk: flutter
  web3dart: ^3.0.0
```

Then, create a new Flutter app and add the following code to the **`lib/main.dart`** file:

```dart
import 'package:flutter/material.dart';
import 'package:web3dart/web3dart.dart';
import 'package:bip39/bip39.dart' as bip39;
import 'package:flutter/services.dart' show rootBundle;

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // Create a new Ethereum client
  final client = Web3Client('https://mainnet.infura.io/v3/your-infura-project-id', Client());

  // Initialize the account and balance
  EthereumAddress _address;
  EtherAmount _balance = EtherAmount.zero();

  @override
  void initState() {
    super.initState();
    _generateAccount();
  }

  // Generate a new Ethereum account
  void _generateAccount() async {
    final mnemonic = bip39.generateMnemonic();
    final seed = bip39.mnemonicToSeed(mnemonic);
    final hdWallet = HDWallet.fromSeed(seed);
    final credentials = hdWallet.credentials;
    setState(() {
      _address = credentials.address;
    });
    _updateBalance();
  }

  // Update the account balance
  void _updateBalance() async {
    final balance = await client.getBalance(_address);
    setState(() {
      _balance = balance.getInEther;
    });
  }

  // Send Ether to another Ethereum address
  void _sendEther(EthereumAddress toAddress, EtherAmount amount) async {
    final credentials = await client.credentialsFromPrivateKey('your-private-key');
    final transaction = await client.sendTransaction(
      credentials,
      Transaction(
        to: toAddress,
        value: amount,
      ),
      fetchChainIdFromNetworkId: true,
    );
    print('Transaction hash: ${transaction.hash}');
    _updateBalance();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ethereum Wallet',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Ethereum Wallet'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Account Address:',
                style: TextStyle(fontSize: 18),
              ),
              Text(
                _address?.hex ?? '',
                style: TextStyle(fontSize: 24),
              ),
              SizedBox(height: 24),
              Text(
                'Account Balance:',
                style: TextStyle(fontSize: 18),
              ),
              Text(
                '${_balance.getValueInUnit(EtherUnit.ether)} ETH',
                style: TextStyle(fontSize: 24),
              ),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => _generateAccount(),
                child: Text('Generate Account'),
              ),
              ElevatedButton(
                onPressed: () => _sendEther(EthereumAddress.fromHex('destination-address'), EtherAmount.fromUnitAndValue(EtherUnit.ether, 0.1)),
                child: Text('Send Ether'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
```

Note that this code is for demonstration purposes only and should not be used in a production