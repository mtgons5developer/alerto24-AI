# Live GPS Tracking

Status: Not started

To implement live GPS tracking from a driver by user in a Flutter app, you can use the following steps:

Request the user's location permission using the **`requestPermission`** method from the **`geolocator`** package.

```dart
LocationPermission permission = await Geolocator.requestPermission();
```

Create a stream of **`Position`** updates using the **`getPositionStream`** method from the **`geolocator`** package.

```dart
StreamSubscription<Position> positionStream = Geolocator.getPositionStream(
  desiredAccuracy: LocationAccuracy.high,
  intervalDuration: Duration(seconds: 10),
).listen((Position position) {
  // handle position updates here
});
```

The **`getPositionStream`** method will continuously update the user's position at the specified interval duration.

Create a **`Marker`** object for the driver's location using the **`google_maps_flutter`** package.

```dart
Marker driverMarker = Marker(
  markerId: MarkerId('driver'),
  position: LatLng(driverLatitude, driverLongitude),
  icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
  infoWindow: InfoWindow(title: 'Driver'),
);
```

You can replace the **`driverLatitude`** and **`driverLongitude`** variables with the driver's current latitude and longitude coordinates.

Create a **`Marker`** object for the user's location using the **`google_maps_flutter`** package.

```dart
Marker userMarker = Marker(
  markerId: MarkerId('user'),
  position: LatLng(userLatitude, userLongitude),
  icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
  infoWindow: InfoWindow(title: 'User'),
);
```

You can replace the **`userLatitude`** and **`userLongitude`** variables with the user's current latitude and longitude coordinates.

Create a **`GoogleMap`** widget using the **`google_maps_flutter`** package, and set the **`initialCameraPosition`** to the user's location.

```dart
GoogleMap(
  initialCameraPosition: CameraPosition(
    target: LatLng(userLatitude, userLongitude),
    zoom: 16,
  ),
  markers: {driverMarker, userMarker},
)
```

This will display the map centered on the user's location, with markers for the driver and user.

Update the driver's marker position and refresh the map when new location updates are received.

```dart
positionStream.listen((Position position) {
  setState(() {
    driverLatitude = position.latitude;
    driverLongitude = position.longitude;
    driverMarker = Marker(
      markerId: MarkerId('driver'),
      position: LatLng(driverLatitude, driverLongitude),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      infoWindow: InfoWindow(title: 'Driver'),
    );
  });
});
```

This will update the driver's marker position and refresh the map every time new location updates are received.

By following these steps, you can implement live GPS tracking from a driver by user in a Flutter app. Keep in mind that location services can drain a device's battery, so you should use them judiciously and provide the user with options to disable or customize location tracking.