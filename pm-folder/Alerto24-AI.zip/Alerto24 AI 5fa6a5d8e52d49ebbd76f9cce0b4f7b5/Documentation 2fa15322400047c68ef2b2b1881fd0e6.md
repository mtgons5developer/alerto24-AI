# Documentation

[https://1drv.ms/p/s!AmIFmdKOP6Da1VBDJOn-a7bV2k6Q?e=GUw5tw](https://1drv.ms/p/s!AmIFmdKOP6Da1VBDJOn-a7bV2k6Q?e=GUw5tw)

[Project Estimate and Billings.xlsx](https://1drv.ms/x/s!AmIFmdKOP6Da1W-nbdDXM6HaDKFK?e=6MDzYN)