# Full App Features

NDMMRC - Alerts

Red Cross - Blood Donations

News Scraper, that will GPT give possible solution.

AI Powered Chat Support

AI Powered Video Editing

ARLT - Coin [https://coinmanufactory.com](https://coinmanufactory.com/)

ETH Network

Crypto Ads Network

Users will able to profit from their uploaded videos.

Funrasing/Donation/Non-Profit

Travel Mode