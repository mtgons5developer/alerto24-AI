# Face detection for emergency.

Status: Not started

****Computer Vision with ML Kit - Flutter In Focus****

[https://www.youtube.com/watch?v=ymyYUCrJnxU&t=312s](https://www.youtube.com/watch?v=ymyYUCrJnxU&t=312s)