# Auto-post Videos in Social Media accounts.

Status: Not started

Here's an example code snippet in Flutter that uses the **`twitter_api`** package to post a video tweet to Twitter:

```dart
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:twitter_api/twitter_api.dart';

class VideoTweetPage extends StatefulWidget {
  @override
  _VideoTweetPageState createState() => _VideoTweetPageState();
}

class _VideoTweetPageState extends State<VideoTweetPage> {
  File _videoFile;
  Uint8List _videoBytes;
  bool _isLoading = false;

  Future<void> _pickVideo() async {
    final pickedFile = await ImagePicker().getVideo(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _videoFile = File(pickedFile.path);
        _videoBytes = await _videoFile.readAsBytes();
      });
    }
  }

  Future<void> _postTweet() async {
    setState(() {
      _isLoading = true;
    });

    final twitterApi = TwitterApi(
      consumerKey: '<your_consumer_key>',
      consumerSecret: '<your_consumer_secret>',
      token: '<your_access_token>',
      tokenSecret: '<your_access_token_secret>',
    );

    // Upload the video to Twitter
    final uploadResponse = await twitterApi.mediaUpload.uploadMedia(
      mediaFile: _videoFile,
      mediaType: 'video/mp4',
      mediaCategory: 'tweet_video',
    );

    // Post the tweet with the uploaded video
    final postResponse = await twitterApi.postTweet(
      status: 'Check out my video!',
      mediaIds: [uploadResponse.mediaId],
    );

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Post a Video Tweet'),
      ),
      body: Center(
        child: _isLoading
            ? CircularProgressIndicator()
            : _videoBytes == null
                ? Text('No video selected.')
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 320,
                        height: 180,
                        child: VideoPlayer(Video.memory(_videoBytes)),
                      ),
                      SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _postTweet,
                        child: Text('Post Tweet'),
                      ),
                    ],
                  ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _pickVideo,
        child: Icon(Icons.video_library),
      ),
    );
  }
}
```

Note that you'll need to replace **`<your_consumer_key>`**, **`<your_consumer_secret>`**, **`<your_access_token>`**, and **`<your_access_token_secret>`** with your actual API keys and access tokens. You can find instructions on how to get these values in the Twitter developer documentation.