# Getting Started with Flutter

[https://github.com/mtgons5developer/alerto24-AI.git](https://github.com/mtgons5developer/alerto24-AI.git)

Locate your flutter SDK

```bash
export PATH="$PATH:pwd/flutter/bin"
export PATH="$PATH:pwd/flutter/bin/cache/dart-sdk/bin"
cd [Flutter-Project-Foler]
```

Folders must include /android and /assets

```bash
flutter run
```