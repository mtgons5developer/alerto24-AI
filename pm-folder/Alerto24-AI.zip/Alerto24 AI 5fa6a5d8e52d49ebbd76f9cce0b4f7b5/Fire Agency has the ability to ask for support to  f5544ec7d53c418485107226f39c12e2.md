# Fire Agency has the ability to ask for support to other Fire Agencies.

Status: Not started