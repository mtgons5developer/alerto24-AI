# News Scraper, that will GPT give possible solution.

Status: Not started

[https://github.com/mtgons5developer/finance_srik](https://github.com/mtgons5developer/finance_srik)

[https://github.com/mtgons5developer/finance_srik](https://github.com/mtgons5developer/finance_srik)